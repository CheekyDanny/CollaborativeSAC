﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

     
        private void solematerialBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            String Value1 = solematerialBox.Text;
            if (Value1 == "Leather")
            {
                soleTextbox.Text = "50";
            }
            else if (Value1 == "Rubber")
            {
                soleTextbox.Text = "30";
            }
            else
            {
                soleTextbox.Text = "10";
            }

        }

        private void topmaterialBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            String Value2 = topmaterialBox.Text;
            if (Value2 == "Leather")
            {
                topTextbox.Text = "100";
            }
            else if (Value2 == "Canvas")
            {
                topTextbox.Text = "50";
            }
            else if (Value2 == "Fake Leather")
            {
                topTextbox.Text = "20";
            }
            else
            {
                topTextbox.Text = "5";
            }



        }

        private void liningBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void colourBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

        }

        private void priceTextbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
